
import java.util.Vector;

/*
 * Implment the assignment 1 using Vector 
 */
public class Solution6 {
    public static void main(String[] args) {
        Vector<String> months = new Vector<>();
        months.add("Jan");
        months.add("Feb");
        months.add("March");
        months.add("April");
        months.add("May");
        months.add("June");
        months.add("July");
        months.add("Aug");
        months.add("Sep");
        months.add("Oct");
        months.add("Nov");
        months.add("Dec");

        System.out.println(months);
    }
}