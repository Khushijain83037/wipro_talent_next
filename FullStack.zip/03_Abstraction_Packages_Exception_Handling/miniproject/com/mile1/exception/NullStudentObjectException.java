package abstraction_packages_exception_handling.miniproject.com.mile1.exception;

public class NullStudentObjectException  extends Exception {
    @Override
    public String toString() {
        return "object is null" ;
    }
}
