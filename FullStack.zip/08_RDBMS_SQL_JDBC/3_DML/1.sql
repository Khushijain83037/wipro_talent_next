CREATE TABLE MY_EMPLOYEE 
As
SELECT employee_id, first_name, last_name, department-ID, salary from EMPLOYEES where 1=2;
