UPDATE MY_EMPLOYEE 
SET last_name =’Higgins’ 
WHERE employee_id = 202;
