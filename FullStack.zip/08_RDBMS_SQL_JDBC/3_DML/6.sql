INSERT ALL
INTO MY_EMPLOYEE (employee_id, first_name, last_name, department_id, salary) 
VALUES (100,'Steven', 'King', 90, 24000),
INTO MY_EMPLOYEE (employee_id, first_name, last_name, department_id, salary) 
VALUES (101, 'Neena', 'Kochar', 90, 17000),
INTO MY_EMPLOYEE (employee_id, first_name, last_name, department_id, salary) 
VALUES (102, 'Lex De', 'Haan', 90, 17000),
INTO MY_EMPLOYEE (employee_id, first_name, last_name, department_id, salary) 
VALUES (111, 'Isamael', 'Sciarra', 100, 7700),
INTO MY_EMPLOYEE (employee_id, first_name, last_name, department_id, salary) 
VALUES (112, 'Jose Manuel', 'Urman', 100, 7800),
INTO MY_EMPLOYEE (employee_id, first_name, last_name, department_id, salary) 
VALUES (204, 'Hermann' , 'Baer', 70, 1000);
SELECT * FROM DUAL;
