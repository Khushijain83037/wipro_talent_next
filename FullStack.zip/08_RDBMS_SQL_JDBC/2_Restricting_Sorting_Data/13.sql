SELECT last_name
FROM employees
WHERE last_name like ‘%a%’ AND last_name like ‘%e%’;
