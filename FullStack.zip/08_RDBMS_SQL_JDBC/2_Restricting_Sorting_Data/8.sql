SELECT last_name,job_id 
FROM employees
WHERE manager_id IS NULL;
 